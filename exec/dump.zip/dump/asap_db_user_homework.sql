-- MySQL dump 10.13  Distrib 8.0.26, for Win64 (x86_64)
--
-- Host: i6A107.p.ssafy.io    Database: asap_db
-- ------------------------------------------------------
-- Server version	8.0.28-0ubuntu0.20.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user_homework`
--

DROP TABLE IF EXISTS `user_homework`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_homework` (
  `userhomeworkno` int NOT NULL AUTO_INCREMENT,
  `userno` int NOT NULL,
  `homeworkno` int NOT NULL,
  `is_done` int NOT NULL DEFAULT '0',
  `filepath` varchar(255) DEFAULT NULL,
  `filename` varchar(45) DEFAULT NULL,
  `ogfilename` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`userhomeworkno`),
  KEY `homework_user_homework_idx` (`homeworkno`),
  KEY `user_user_homework_idx` (`userno`),
  CONSTRAINT `homework_user_homework` FOREIGN KEY (`homeworkno`) REFERENCES `homework` (`homeworkno`),
  CONSTRAINT `user_user_homework` FOREIGN KEY (`userno`) REFERENCES `user` (`userno`)
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_homework`
--

LOCK TABLES `user_homework` WRITE;
/*!40000 ALTER TABLE `user_homework` DISABLE KEYS */;
INSERT INTO `user_homework` VALUES (39,21,24,0,NULL,NULL,NULL),(40,23,24,1,'https://asap-ssafy-bucket.s3.ap-northeast-2.amazonaws.com/homework/707d2049-b985-48de-98f3-f5d8375ab57750b3df03222a295535c3b5bd8bec1e0a.txt','test','백준111111번_코드.txt'),(41,25,24,1,'https://asap-ssafy-bucket.s3.ap-northeast-2.amazonaws.com/homework/2f93834c-adec-4af0-8bf9-9939c07f87897b7c04053a24803b6876082e1c52ec0d.java','test','AppointmentLogic.java'),(42,26,24,0,NULL,NULL,NULL),(43,21,25,0,NULL,NULL,NULL),(44,23,25,1,'https://asap-ssafy-bucket.s3.ap-northeast-2.amazonaws.com/homework/2a33a427-ef31-4a80-852f-b88cdd954e37c6c1ab705805c91c32dbf99973b2aaf0.txt','test','프로그래머스 어쩌구저쩌구_코드.txt'),(45,25,25,0,NULL,NULL,NULL),(46,26,25,0,NULL,NULL,NULL),(47,23,26,0,NULL,NULL,NULL),(48,25,26,0,NULL,NULL,NULL),(49,23,27,0,NULL,NULL,NULL),(50,23,28,0,NULL,NULL,NULL),(51,25,28,0,NULL,NULL,NULL),(52,21,29,0,NULL,NULL,NULL),(53,23,29,0,NULL,NULL,NULL),(58,21,31,0,NULL,NULL,NULL),(59,23,31,1,'https://asap-ssafy-bucket.s3.ap-northeast-2.amazonaws.com/homework/b76fb4dd-34a3-4a3e-96b4-e07a3c4b6aac93a9b7d6989afefdd71416a42b7d8c92.txt','test','과제.txt'),(60,25,31,0,NULL,NULL,NULL),(61,26,31,0,NULL,NULL,NULL);
/*!40000 ALTER TABLE `user_homework` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-02-17 17:11:28
