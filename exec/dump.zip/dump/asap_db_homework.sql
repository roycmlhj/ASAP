-- MySQL dump 10.13  Distrib 8.0.26, for Win64 (x86_64)
--
-- Host: i6A107.p.ssafy.io    Database: asap_db
-- ------------------------------------------------------
-- Server version	8.0.28-0ubuntu0.20.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `homework`
--

DROP TABLE IF EXISTS `homework`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `homework` (
  `homeworkno` int NOT NULL AUTO_INCREMENT,
  `studyno` int NOT NULL,
  `start_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `end_date` datetime NOT NULL,
  `is_active` int NOT NULL DEFAULT '0',
  `content` varchar(200) DEFAULT NULL,
  `title` varchar(45) NOT NULL,
  `userno` int NOT NULL,
  PRIMARY KEY (`homeworkno`),
  KEY `studyno_idx` (`studyno`),
  KEY `user_homework_idx` (`userno`),
  CONSTRAINT `study_homework` FOREIGN KEY (`studyno`) REFERENCES `study` (`studyno`),
  CONSTRAINT `user_homework` FOREIGN KEY (`userno`) REFERENCES `user` (`userno`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `homework`
--

LOCK TABLES `homework` WRITE;
/*!40000 ALTER TABLE `homework` DISABLE KEYS */;
INSERT INTO `homework` VALUES (24,33,'2022-02-17 06:10:22','2022-02-20 00:00:00',0,'BFS/DFS 두가지 방식을 모두 사용하여 백준 111111번 풀기!','백준 111111번 풀기!',23),(25,33,'2022-02-17 06:11:18','2022-02-22 00:00:00',0,'효율성에 비중을 두어 풀어보자!','프로그래머스 어쩌구저쩌구 문제 풀기!',23),(26,34,'2022-02-17 06:34:35','2022-02-25 00:00:00',0,'풀어오세욥','하양이 모의고사 1 풀어오기',25),(27,36,'2022-02-17 06:34:52','2022-02-23 00:00:00',0,'반드시 시간을 재면서 풀어봅시당','위포트 수리영역 59p~64p 풀기',23),(28,34,'2022-02-17 06:35:12','2022-02-19 00:00:00',0,'푼 거 사진 찍어서 인증 필','파랑이 모의고사 1 풀어오기',25),(29,37,'2022-02-17 06:35:35','2022-02-23 00:00:00',0,'1분 자기소개 작성해서 스크립트 올리기!','1분 자기소개 작성',21),(31,33,'2022-02-17 07:05:34','2022-02-18 00:00:00',0,'test','test',23);
/*!40000 ALTER TABLE `homework` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-02-17 17:11:28
