-- MySQL dump 10.13  Distrib 8.0.26, for Win64 (x86_64)
--
-- Host: i6A107.p.ssafy.io    Database: asap_db
-- ------------------------------------------------------
-- Server version	8.0.28-0ubuntu0.20.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `board`
--

DROP TABLE IF EXISTS `board`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `board` (
  `boardno` int NOT NULL AUTO_INCREMENT,
  `boardname` varchar(45) NOT NULL,
  `userno` int NOT NULL,
  `timestamp` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `studyno` int NOT NULL,
  `boarddescription` varchar(200) NOT NULL,
  `link` varchar(100) DEFAULT NULL,
  `contactlink` varchar(100) DEFAULT NULL,
  `maxmember` int NOT NULL DEFAULT '2',
  `is_recruit` int NOT NULL DEFAULT '0',
  `hit` int NOT NULL DEFAULT '0',
  `interests` varchar(1000) DEFAULT NULL,
  `category` varchar(1000) DEFAULT NULL,
  `nickname` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`boardno`),
  KEY `email_idx` (`userno`),
  KEY `studyno_idx` (`studyno`),
  CONSTRAINT `email` FOREIGN KEY (`userno`) REFERENCES `user` (`userno`),
  CONSTRAINT `studyno` FOREIGN KEY (`studyno`) REFERENCES `study` (`studyno`) ON DELETE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `board`
--

LOCK TABLES `board` WRITE;
/*!40000 ALTER TABLE `board` DISABLE KEYS */;
INSERT INTO `board` VALUES (20,'CS 스터디 스터디원 모집합니다~',21,'2022-02-17 05:58:35',32,'취업을 위한 CS스터디입니다.\n일주일에 한번씩 모여서 CS에 관한 지식을 서로 주고 받습니다.\ncs에 대해서 1도 모르시는 분, cs를 엄청 잘 아시는 분 모두모두 환영입니다',NULL,'스터디장 : 010-1111-2222',6,0,15,'#cs','과학/공학/기술/IT','자루빗'),(21,'GSAT 같이 공부해용',25,'2022-02-17 06:01:21',34,'삼성 GSAT 대비 스터디입니다.\n매주 토요일 12시~2시\n모여서 모의고사 문제 풀이 리뷰하고 풀이법 공유,\n시간 제한 모의고사 시험 칩니다\n지난 시즌 준비해보신 분 우대합니다.','notion/gsat/nomeaning/1','010-1111-2222',6,0,13,'#SAMSUNG#GSAT#삼성','과학/공학/기술/IT','룰루랄라'),(22,'알고리즘 뿌수기 스터디',23,'2022-02-17 06:03:03',33,'1일 1알고리즘!!!!!!!!\n알고리즘 스터디를 중점적으로 하는 스터디 입니다!!\n일주일에 2번 스터디를 진행합니다!!',NULL,'전화번호 : 010-1234-5678, 카톡ID : qwer1111',4,0,14,'##알고리즘##백준##프로그래머스##SWEA','과학/공학/기술/IT','감바스'),(23,'열정 NCS 스터디 스터디원 모집합니다!!',26,'2022-02-17 06:03:35',35,'주 2회 아침스터디 입니다.\n시간 재며 문제 풀고 문제 리뷰하는 형식으로 진행하고 있습니다\n시간 엄수 잡담 금지!!',NULL,'010-3456-7890',6,0,18,'#ncs#공기업','과학/공학/기술/IT','공돌이'),(24,'면접 스터디',21,'2022-02-17 06:34:55',37,'각종 뷰티 관련 회사 면접 스터디입니다.\n올리브영, 아모레퍼시픽, MAC을 주 면접 대상 회사로 선정하였습니다.',NULL,'스터디장 : 010-1111-2222, 카톡 : ssafy',4,0,5,'#올리브영#아모레퍼시픽#MAC','뷰티/미용/화장품','자루빗'),(25,'테스트 스터디',21,'2022-02-17 07:16:58',38,'테스트 스터디입니다.',NULL,NULL,6,0,4,'','기타','자루빗');
/*!40000 ALTER TABLE `board` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-02-17 17:11:29
