-- MySQL dump 10.13  Distrib 8.0.26, for Win64 (x86_64)
--
-- Host: i6A107.p.ssafy.io    Database: asap_db
-- ------------------------------------------------------
-- Server version	8.0.28-0ubuntu0.20.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `study`
--

DROP TABLE IF EXISTS `study`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `study` (
  `studyno` int NOT NULL AUTO_INCREMENT,
  `category` varchar(45) NOT NULL,
  `description` varchar(200) NOT NULL,
  `memberno` int DEFAULT '1',
  `maker` varchar(45) NOT NULL,
  `studyname` varchar(45) NOT NULL,
  `interests` varchar(1000) DEFAULT NULL,
  `timestamp` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`studyno`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `study`
--

LOCK TABLES `study` WRITE;
/*!40000 ALTER TABLE `study` DISABLE KEYS */;
INSERT INTO `study` VALUES (32,'과학/공학/기술/IT','취업 스터디입니다.\n일주일에 한번씩 모여서 CS에 관한 지식을 서로 주고 받습니다.',6,'roycmlhj@naver.com','CS 스터디','#cs','2022-02-17 05:57:00'),(33,'과학/공학/기술/IT','1일 1알고리즘!!!!!!!!\n알고리즘 스터디를 중점적으로 하는 스터디 입니다!!\n일주일에 2번 스터디를 진행합니다!!',4,'woot5785@naver.com','알고리즘 뿌수기 스터디','##알고리즘##백준##프로그래머스##SWEA','2022-02-17 06:00:02'),(34,'과학/공학/기술/IT','삼성 GSAT 대비 스터디입니다.\n매주 토요일 12시~2시\n모여서 모의고사 문제 풀이 리뷰하고 풀이법 공유,\n시간 제한 모의고사 시험 칩니다\n지난 시즌 준비해보신 분 우대합니다.',6,'budludl@naver.com','GSAT 같이 공부해용','#SAMSUNG#GSAT#삼성','2022-02-17 06:00:44'),(35,'과학/공학/기술/IT','주 2회 아침스터디\n시간 재며 문제 풀고 문제 리뷰하는 형식으로 진행하는 스터디 입니다.',6,'kww55516@naver.com','열정 NCS 스터디','#ncs#공기업','2022-02-17 06:02:32'),(36,'기타',' ncs 스터디입니다.\n각자의 노하우를 공유하며 모든 필기 시험을 통과해봅시다!',4,'woot5785@naver.com','NCS 완전 정복 스터디','#ncs#금융권','2022-02-17 06:33:27'),(37,'뷰티/미용/화장품','각종 뷰티 관련 회사 면접 스터디입니다.',4,'roycmlhj@naver.com','면접 스터디','#올리브영#아모레퍼시픽#MAC','2022-02-17 06:34:05'),(38,'기타','테스트 스터디입니다.',6,'roycmlhj@naver.com','테스트 스터디','','2022-02-17 07:16:51');
/*!40000 ALTER TABLE `study` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-02-17 17:11:30
